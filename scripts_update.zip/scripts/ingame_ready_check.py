# scripts/ingame_ready_check.py
import time
import pyautogui
import ctypes
from ctypes import wintypes

user32 = ctypes.windll.user32
GetWindowRect = user32.GetWindowRect

# Vaste coördinaten
SWITCH_MAP_COORD = (65, 680)
CANCEL_COORD = (501, 530)

def get_window_pos(hwnd):
    rect = wintypes.RECT()
    GetWindowRect(hwnd, ctypes.byref(rect))
    return rect.left, rect.top, rect.right, rect.bottom

def click(hwnd, x, y):
    left, top, _, _ = get_window_pos(hwnd)
    pyautogui.click(left + x, top + y)

def find_png(hwnd, image, confidence=0.70, timeout=2.0):
    left, top, right, bottom = get_window_pos(hwnd)
    width, height = right - left, bottom - top
    end = time.time() + timeout
    while time.time() < end:
        try:
            match = pyautogui.locateCenterOnScreen(image, confidence=confidence, region=(left, top, width, height))
            if match: return match
        except: pass
        time.sleep(0.1)
    return None

def esc_failsafe(hwnd, multiplier, max_attempts=12):
    """Gebruikt de multiplier voor de pauzes tussen ESC-drukken."""
    print(f"[READY-FAILSAFE] Opschonen voor hwnd={hwnd}")
    for i in range(max_attempts):
        pyautogui.press("esc")
        # De multiplier past de snelheid aan (bijv. 0.4 * 0.5 = 0.2s voor snelle pc's)
        time.sleep(0.4 * multiplier) 

        match = find_png(hwnd, "assets/bg_cancel.png", confidence=0.55, timeout=0.1)
        if match:
            click(hwnd, *CANCEL_COORD)
            time.sleep(0.5 * multiplier)
            return True
    return False

def run(hwnd, heal_mode=False, multiplier=1.0):
    """
    multiplier: haalt de waarde op uit de GUI
    """
    print(f"[READY CHECK] Start voor hwnd={hwnd} (Speed: {multiplier}x)")

    # 1. Failsafe met multiplier
    if not esc_failsafe(hwnd, multiplier):
        print(f"[READY CHECK] Failsafe mislukt voor hwnd={hwnd}")
        return False

    # 2. Locatie check
    if heal_mode:
        if find_png(hwnd, "assets/shelter.png", confidence=0.65, timeout=1.0):
            click(hwnd, *SWITCH_MAP_COORD)
            time.sleep(4.0 * multiplier)
    else:
        if find_png(hwnd, "assets/region.png", confidence=0.65, timeout=1.0):
            click(hwnd, *SWITCH_MAP_COORD)
            time.sleep(4.0 * multiplier)
            
    return True