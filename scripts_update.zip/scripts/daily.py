# scripts/daily.py
import time
import pyautogui
import ctypes
from ctypes import wintypes
from scripts import config  # Importeer de globale multiplier

# Win32 API setup
user32 = ctypes.windll.user32
GetWindowRect = user32.GetWindowRect

# Standaard vertragingen nu afhankelijk van de multiplier
DEFAULT_DELAY = 2.0
LONG_DELAY = 4.0

CANCEL_COORD = (501, 530)
BACK_ARROW = (49, 70)

# Jouw originele clicks t/m 37
CLICKS = [
    (139, 90), (770, 630), (879, 120), (1082, 216), (1076, 212),
    (1180, 115), (777, 670), (777, 670), (201, 382), (165, 669),
    (142, 70), (68, 668), (548, 523), (852, 525), (1151, 521),
    (1220, 372), (541, 520), (837, 527), (1143, 526), (545, 297),
    (545, 297), (545, 297), (545, 297), (545, 297), (1224, 165),
    (39, 76), (482, 381), (97, 647), (668, 595), (972, 279),
    (51, 75), (1042, 399), (1194, 90), (1184, 638), (147, 75),
    (120, 616), (152, 68),
]

LONG_DELAY_INDICES = {2, 4, 11, 35, 36}

# ==========================
# HELPER FUNCTIES
# ==========================

def get_window_pos(hwnd):
    rect = wintypes.RECT()
    GetWindowRect(hwnd, ctypes.byref(rect))
    return rect.left, rect.top, rect.right, rect.bottom

def click(hwnd, x, y):
    left, top, _, _ = get_window_pos(hwnd)
    abs_x = left + x
    abs_y = top + y
    pyautogui.click(abs_x, abs_y)

def find_png(hwnd, image, confidence=0.70, timeout=2.0):
    left, top, right, bottom = get_window_pos(hwnd)
    width = right - left
    height = bottom - top
    
    # Pas de timeout aan op basis van de snelheid
    actual_timeout = timeout * config.speed_multiplier
    end = time.time() + actual_timeout
    while time.time() < end:
        try:
            match = pyautogui.locateCenterOnScreen(
                image, 
                confidence=confidence, 
                region=(left, top, width, height)
            )
            if match:
                return match
        except Exception:
            pass
        time.sleep(0.1 * config.speed_multiplier)
    return None

def esc_failsafe(hwnd, max_attempts=12):
    """
    De nieuwe krachtige failsafe: 
    Blijft drukken tot de bg_cancel popup verschijnt en klikt dan op de vaste cancel-knop.
    """
    print(f"[FAILSAFE] Opschonen voor hwnd={hwnd}")
    for i in range(max_attempts):
        pyautogui.press("esc")
        time.sleep(0.4 * config.speed_multiplier) 

        # Check of we het afsluitscherm zien
        match = find_png(hwnd, "assets/bg_cancel.png", confidence=0.55, timeout=0.1)
        if match:
            print(f"[FAILSAFE] Popup herkend. Klik op Cancel.")
            click(hwnd, *CANCEL_COORD)
            time.sleep(0.5 * config.speed_multiplier)
            return True
            
    return False

# ==========================
# MAIN FLOW
# ==========================

def run(hwnd):
    print(f"[Daily] Start daily flow voor hwnd={hwnd}")

    # 1. ESC-reset aan begin
    esc_failsafe(hwnd)
    time.sleep(1.0 * config.speed_multiplier)

    # 2. Clicks 1 t/m 37
    for index, (x, y) in enumerate(CLICKS, start=1):
        print(f"[Daily] Click {index}: ({x}, {y})")
        click(hwnd, x, y)

        # Bepaal delay en pas multiplier toe
        base_delay = LONG_DELAY if index in LONG_DELAY_INDICES else DEFAULT_DELAY
        time.sleep(base_delay * config.speed_multiplier)

    # 3. Back arrows (Stappen 38 & 39)
    print("[Daily] Back arrows navigeren...")
    click(hwnd, *BACK_ARROW)
    time.sleep(1.5 * config.speed_multiplier)
    click(hwnd, *BACK_ARROW)
    time.sleep(1.5 * config.speed_multiplier)

    # 4. Afsluiten met de krachtige failsafe
    esc_failsafe(hwnd)

    print(f"[Daily] Daily flow klaar voor hwnd={hwnd}")