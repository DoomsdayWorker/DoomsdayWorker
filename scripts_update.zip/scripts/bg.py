# scripts/bg.py
import time
import pyautogui
import ctypes
from ctypes import wintypes
from scripts import config  # Importeer de globale multiplier

# Win32 API setup
user32 = ctypes.windll.user32
GetWindowRect = user32.GetWindowRect

DEFAULT_DELAY = 1.0
CANCEL_COORD = (501, 530)

# ==========================
# HELPER FUNCTIES
# ==========================

def get_window_pos(hwnd):
    rect = wintypes.RECT()
    GetWindowRect(hwnd, ctypes.byref(rect))
    return rect.left, rect.top, rect.right, rect.bottom

def click(hwnd, x, y):
    left, top, _, _ = get_window_pos(hwnd)
    abs_x = left + x
    abs_y = top + y
    pyautogui.click(abs_x, abs_y)

def find_png(hwnd, image, confidence=0.70, timeout=1.0):
    left, top, right, bottom = get_window_pos(hwnd)
    width = right - left
    height = bottom - top
    
    # Pas timeout aan op basis van snelheid
    actual_timeout = timeout * config.speed_multiplier
    end = time.time() + actual_timeout
    while time.time() < end:
        try:
            match = pyautogui.locateCenterOnScreen(
                image, 
                confidence=confidence, 
                region=(left, top, width, height)
            )
            if match:
                return match
        except Exception:
            pass
        time.sleep(0.1 * config.speed_multiplier)
    return None

def esc_failsafe(hwnd, max_attempts=12):
    """
    De universele krachtige failsafe: 
    Blijft ESC drukken tot bg_cancel verschijnt en drukt dan op de vaste cancel-knop.
    """
    print(f"[FAILSAFE] Opschonen voor hwnd={hwnd}")
    for i in range(max_attempts):
        pyautogui.press("esc")
        time.sleep(0.4 * config.speed_multiplier) 
        
        # Gebruik 0.55 confidence zoals afgesproken voor de popup
        match = find_png(hwnd, "assets/bg_cancel.png", confidence=0.55, timeout=0.1)
        if match:
            print(f"[FAILSAFE] Afsluitscherm herkend. Klik op Cancel.")
            click(hwnd, *CANCEL_COORD)
            time.sleep(0.5 * config.speed_multiplier)
            return True
    return False

# ==========================
# HOOFD FLOW
# ==========================

def run(hwnd):
    print(f"[BG] Start BattleGround flow voor hwnd={hwnd}")

    # 0) ESC-reset aan begin
    esc_failsafe(hwnd)
    time.sleep(1.0 * config.speed_multiplier)

    # --- 1) Check of BG al bezig is ---
    print("[BG] Controleren of BG al actief is...")
    active = find_png(hwnd, "assets/bg_actief.png", confidence=0.75, timeout=2.0)

    if active:
        print("[BG] BG is al bezig → flow overslaan")
        return

    print("[BG] BG is NIET bezig → BG starten")

    # --- 2) Gewone kliks om BG te starten ---
    click(hwnd, 795, 669)
    time.sleep(DEFAULT_DELAY * config.speed_multiplier)

    click(hwnd, 1007, 415)
    time.sleep(DEFAULT_DELAY * config.speed_multiplier)

    click(hwnd, 650, 564)
    time.sleep(DEFAULT_DELAY * config.speed_multiplier)

    # --- 3) Terug naar startpositie ---
    print("[BG] Terug naar startpositie (back arrows)...")
    click(hwnd, 47, 63)
    time.sleep(DEFAULT_DELAY * config.speed_multiplier)

    click(hwnd, 47, 63)
    time.sleep(DEFAULT_DELAY * config.speed_multiplier)

    # --- 4) Wachten op cancel-knop (BG klaar) ---
    print("[BG] Wachten op cancel-knop (max 5 minuten)...")
    max_wait = 300  # 5 minuten (cycles)

    for i in range(max_wait):
        # Zoek specifiek naar het afsluitscherm aan het einde van de battle
        cancel = find_png(hwnd, "assets/bg_cancel.png", confidence=0.70, timeout=0.5)
        if cancel:
            print("[BG] Battle klaar: Cancel-knop gevonden → klikken")
            # Directe schermklik op de gevonden PNG
            pyautogui.click(cancel.x, cancel.y)
            time.sleep(DEFAULT_DELAY * config.speed_multiplier)

            # Extra opschonen om zeker te zijn
            esc_failsafe(hwnd)
            print("[BG] BG flow klaar")
            return

        if i % 10 == 0:
            print(f"[BG] Nog aan het wachten... ({i}s)")
            
        # Wachtstap ook afhankelijk van multiplier
        time.sleep(1.0 * config.speed_multiplier)

    # --- 5) Timeout → ESC failsafe ---
    print("[BG] Timeout: Battle duurde te lang → ESC-reset")
    esc_failsafe(hwnd)

    print(f"[BG] BG flow klaar (via timeout) voor hwnd={hwnd}")