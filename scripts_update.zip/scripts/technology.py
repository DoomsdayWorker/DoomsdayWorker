# scripts/technology.py
import time
import pyautogui
import ctypes
from ctypes import wintypes
from scripts import config  # Importeer de globale multiplier

# Win32 API setup
user32 = ctypes.windll.user32
GetWindowRect = user32.GetWindowRect

DEFAULT_DELAY = 1.0
CANCEL_COORD = (501, 530)

# ==========================
# HELPER FUNCTIES
# ==========================

def get_window_pos(hwnd):
    rect = wintypes.RECT()
    GetWindowRect(hwnd, ctypes.byref(rect))
    return rect.left, rect.top, rect.right, rect.bottom

def click(hwnd, x, y):
    left, top, _, _ = get_window_pos(hwnd)
    abs_x = left + x
    abs_y = top + y
    pyautogui.click(abs_x, abs_y)

def find_png(hwnd, image, confidence=0.70, timeout=3.0):
    left, top, right, bottom = get_window_pos(hwnd)
    width = right - left
    height = bottom - top
    
    # Pas timeout aan op basis van snelheid
    actual_timeout = timeout * config.speed_multiplier
    end = time.time() + actual_timeout
    while time.time() < end:
        try:
            match = pyautogui.locateCenterOnScreen(
                image, 
                confidence=confidence, 
                region=(left, top, width, height)
            )
            if match:
                return match
        except Exception:
            pass
        time.sleep(0.1 * config.speed_multiplier)
    return None

def esc_failsafe(hwnd, max_attempts=12):
    """
    De universele krachtige failsafe: 
    Blijft op ESC drukken tot bg_cancel.png verschijnt en klikt dan op de vaste cancel-knop.
    """
    print(f"[FAILSAFE] Opschonen voor hwnd={hwnd}")
    for i in range(max_attempts):
        pyautogui.press("esc")
        time.sleep(0.4 * config.speed_multiplier) 

        # Check of de exit popup er is (0.55 confidence conform afspraak)
        match = find_png(hwnd, "assets/bg_cancel.png", confidence=0.55, timeout=0.1)
        if match:
            # Gebruik de vaste coördinaat voor consistentie
            click(hwnd, *CANCEL_COORD)
            time.sleep(0.5 * config.speed_multiplier)
            return True
            
    return False

# ==========================
# HOOFD FLOW
# ==========================

def run(hwnd):
    print(f"[TechDonations] Start flow voor hwnd={hwnd}")

    # 1) Zorg dat we in het hoofdmenu staan
    esc_failsafe(hwnd)
    time.sleep(1.0 * config.speed_multiplier)

    # --- 1) Alliance openen ---
    click(hwnd, 960, 670)
    time.sleep(DEFAULT_DELAY * config.speed_multiplier)

    # --- 2) Tech-menu openen ---
    click(hwnd, 999, 618)
    time.sleep(DEFAULT_DELAY * config.speed_multiplier)

    # --- 3) PNG-detectie: tech_marker.png ---
    match = find_png(hwnd, "assets/tech_marker.png", confidence=0.65, timeout=3.0)

    if not match:
        print("[TechDonations] tech_marker.png NIET gevonden — flow afgebroken")
        esc_failsafe(hwnd)
        return

    # Direct klikken op de gevonden PNG locatie
    pyautogui.click(match.x, match.y)
    time.sleep(DEFAULT_DELAY * config.speed_multiplier)

    # --- 4) Donaties: 5x ---
    donate_x, donate_y = 974, 605
    for i in range(5):
        click(hwnd, donate_x, donate_y)
        # Korte pauze tussen donaties ook afhankelijk van multiplier
        time.sleep(0.6 * config.speed_multiplier)

    # --- 5) Terug naar af ---
    print("[TechDonations] Donaties klaar. Terug naar kaart.")
    esc_failsafe(hwnd)
    
    print(f"[TechDonations] Klaar voor hwnd={hwnd}")