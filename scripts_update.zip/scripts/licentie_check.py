import subprocess
import requests

# Hier plak je de URL die je kreeg bij het implementeren van je Google Script
GOOGLE_SCRIPT_URL = "https://script.google.com/macros/s/AKfycbxZq0-wtT4hj4N5qqQbp_ZGBzhSuWwpNN87fHSz5vd-brcO1yU5OKdVhHrDCPhvDJPs9g/exec"

def get_hwid():
    """Haalt de unieke hardware ID van de PC op."""
    try:
        # We pakken het UUID van de computer
        cmd = 'wmic csproduct get uuid'
        uuid = subprocess.check_output(cmd, shell=True).decode().split('\n')[1].strip()
        return uuid
    except:
        return "UNKNOWN_ID"

def controleer_licentie(sleutel):
    """Checkt de sleutel en HWID tegen de Google Sheet."""
    hwid = get_hwid()
    
    params = {
        "key": sleutel,
        "hwid": hwid
    }
    
    try:
        response = requests.get(GOOGLE_SCRIPT_URL, params=params, timeout=10)
        return response.text # Geeft terug: "GELDIG", "AL_IN_GEBRUIK" of "ONGELDIG"
    except Exception as e:
        return f"ERROR: {e}"

if __name__ == "__main__":
    # Test gedeelte om te zien of het werkt
    test_sleutel = input("Voer een test-sleutel in: ")
    resultaat = controleer_licentie(test_sleutel)
    print(f"Resultaat van de check: {resultaat}")