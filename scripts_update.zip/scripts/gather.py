# scripts/gather.py
import time
import pyautogui
import ctypes
import random
from ctypes import wintypes
from scripts import config  # Importeer de globale multiplier

# Win32 API setup
user32 = ctypes.windll.user32
GetWindowRect = user32.GetWindowRect

DEFAULT_DELAY = 1.0
CANCEL_COORD = (501, 530)

# Coördinaten (venster-relatief)
SEARCH_COORD = (50, 475)
RSS_SELECT = {
    "food":  (549, 642),
    "wood":  (712, 642),
    "steel": (879, 641),
    "oil":   (1036, 637),
}
RSS_FIND = {
    "food":  (546, 491),
    "wood":  (714, 493),
    "steel": (879, 491),
    "oil":   (1032, 494),
}
NODE_CONFIRM_COORD = (640, 387)
GATHER_COORD       = (983, 525)
CREATE_COORD       = (966, 276)
MARCH_COORD        = (939, 668)
REGIO_COORD        = (81, 668)

# ==========================
# HELPER FUNCTIES
# ==========================

def get_window_pos(hwnd):
    rect = wintypes.RECT()
    GetWindowRect(hwnd, ctypes.byref(rect))
    return rect.left, rect.top, rect.right, rect.bottom

def click(hwnd, x, y):
    left, top, _, _ = get_window_pos(hwnd)
    abs_x = left + x
    abs_y = top + y
    pyautogui.click(abs_x, abs_y)

def human_tap(hwnd, x, y):
    left, top, _, _ = get_window_pos(hwnd)
    abs_x = left + x + random.randint(-2, 2)
    abs_y = top + y + random.randint(-2, 2)
    pyautogui.moveTo(abs_x, abs_y, duration=0.1 * config.speed_multiplier)
    pyautogui.mouseDown(button='left')
    time.sleep(0.18 * config.speed_multiplier) 
    pyautogui.mouseUp(button='left')

def find_png(hwnd, image, confidence=0.70, timeout=2.0):
    left, top, right, bottom = get_window_pos(hwnd)
    width, height = right - left, bottom - top
    # Pas timeout aan op basis van snelheid
    actual_timeout = timeout * config.speed_multiplier
    end = time.time() + actual_timeout
    while time.time() < end:
        try:
            match = pyautogui.locateCenterOnScreen(image, confidence=confidence, region=(left, top, width, height))
            if match: return match
        except: pass
        time.sleep(0.1 * config.speed_multiplier)
    return None

def esc_failsafe(hwnd, max_attempts=12):
    print(f"[FAILSAFE] Opschonen voor hwnd={hwnd}")
    for i in range(max_attempts):
        pyautogui.press("esc")
        time.sleep(0.4 * config.speed_multiplier) 
        match = find_png(hwnd, "assets/bg_cancel.png", confidence=0.55, timeout=0.1)
        if match:
            click(hwnd, *CANCEL_COORD)
            time.sleep(0.5 * config.speed_multiplier)
            return True
    return False

# ==========================
# HOOFD FLOW
# ==========================

def run(hwnd, gather_choices):
    print(f"[Gather] Start volledige vulling voor hwnd={hwnd}")

    if not gather_choices:
        print("[Gather] Geen RSS geselecteerd.")
        return

    # We proberen maximaal 6 keer (meestal heb je max 5 of 6 squads)
    for squad_nr in range(1, 7):
        print(f"[Gather] Poging voor squad #{squad_nr}")
        
        # 1. Start elke ronde neutraal
        esc_failsafe(hwnd)
        time.sleep(0.5 * config.speed_multiplier)

        # 2. Kies RSS
        rss = random.choice(gather_choices)
        
        # 3. Search openen
        click(hwnd, *SEARCH_COORD)
        time.sleep(1.2 * config.speed_multiplier)

        # 4. Resource type selecteren
        click(hwnd, *RSS_SELECT[rss])
        time.sleep(1.0 * config.speed_multiplier)

        # 5. Node zoeken op kaart
        click(hwnd, *RSS_FIND[rss])
        time.sleep(2.5 * config.speed_multiplier) 

        # 6. Node bevestigen
        human_tap(hwnd, *NODE_CONFIRM_COORD)
        time.sleep(1.0 * config.speed_multiplier)

        # 7. Gather knop klikken
        click(hwnd, *GATHER_COORD)
        time.sleep(1.5 * config.speed_multiplier)

        # 8. DE CRUCIALE CHECK: Is er een vrije plek?
        vrije_plek = find_png(hwnd, "assets/vrije_plek.png", confidence=0.75, timeout=2.0)
        
        if not vrije_plek:
            print(f"[Gather] Geen 'vrije_plek.png' meer gedetecteerd. Alle rijen zijn vol!")
            esc_failsafe(hwnd)
            break # Stop de loop, we zijn klaar

        # 9. Create squad
        click(hwnd, *CREATE_COORD)
        time.sleep(1.0 * config.speed_multiplier)

        # 10. March
        click(hwnd, *MARCH_COORD)
        time.sleep(2.0 * config.speed_multiplier)
        print(f"[Gather] Squad #{squad_nr} verzonden naar {rss}")

    print(f"[Gather] Klaar met alle beschikbare wachtrijen voor hwnd={hwnd}")