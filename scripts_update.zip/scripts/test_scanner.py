# scripts/test_scanner.py
import os
import configparser

def scan_sandboxie_config():
    """
    Leest de Sandboxie.ini uit om de namen van alle aangemaakte sandboxen te vinden.
    """
    # Standaard locaties voor de configuratie
    potential_paths = [
        r"C:\Windows\Sandboxie.ini",
        r"C:\Program Files\Sandboxie-Plus\Sandboxie.ini",
        os.path.expanduser("~") + r"\AppData\Local\Sandboxie-Plus\Sandboxie.ini"
    ]
    
    found_boxes = []
    
    # Zoek naar het bestand
    ini_path = None
    for path in potential_paths:
        if os.path.exists(path):
            ini_path = path
            break
            
    if not ini_path:
        print("[ERROR] Sandboxie.ini niet gevonden op de standaard locaties.")
        return []

    try:
        # We gebruiken een simpele tekst-scan omdat Sandboxie.ini 
        # soms rare tekens bevat waar de standaard configparser over struikelt
        with open(ini_path, 'r', encoding='utf-16' if os.path.getsize(ini_path) > 0 else 'utf-8') as f:
            lines = f.readlines()
            
        for line in lines:
            line = line.strip()
            # Zoek naar secties zoals [BoxName]
            if line.startswith('[') and line.endswith(']') and line != '[GlobalSettings]':
                box_name = line[1:-1] # Haal de haakjes weg
                # Filter systeem-secties van Sandboxie uit
                if box_name not in ['GlobalSettings', 'UserSettings_']:
                    found_boxes.append(box_name)
                    
    except Exception as e:
        print(f"[ERROR] Fout bij lezen Sandboxie.ini: {e}")
        
    return found_boxes