# scripts/aod_store.py
import time
import pyautogui
import ctypes
from ctypes import wintypes
from scripts import config  # Importeer de globale multiplier

# Win32 API setup
user32 = ctypes.windll.user32
GetWindowRect = user32.GetWindowRect

DEFAULT_DELAY = 1.2
CANCEL_COORD = (501, 530)

# De coördinaten die je hebt geregistreerd
AOD_CLICKS = [
    (771, 671), (468, 416), (97, 649), (670, 600),
    (959, 270), (1204, 122), (330, 412), (503, 408),
    (503, 408), (1013, 572), (876, 569), (1210, 154),
    (46, 67), (46, 67)
]

# ==========================
# HELPER FUNCTIES
# ==========================

def get_window_pos(hwnd):
    rect = wintypes.RECT()
    GetWindowRect(hwnd, ctypes.byref(rect))
    return rect.left, rect.top, rect.right, rect.bottom

def click(hwnd, x, y):
    left, top, _, _ = get_window_pos(hwnd)
    abs_x = left + x
    abs_y = top + y
    pyautogui.click(abs_x, abs_y)

def find_png(hwnd, image, confidence=0.70, timeout=2.0):
    left, top, right, bottom = get_window_pos(hwnd)
    width, height = right - left, bottom - top
    # Pas de timeout ook aan op basis van snelheid voor consistentie
    actual_timeout = timeout * config.speed_multiplier
    end = time.time() + actual_timeout
    while time.time() < end:
        try:
            match = pyautogui.locateCenterOnScreen(image, confidence=confidence, region=(left, top, width, height))
            if match: return match
        except: pass
        time.sleep(0.1 * config.speed_multiplier)
    return None

def esc_failsafe(hwnd, max_attempts=12):
    """De universele krachtige failsafe."""
    print(f"[FAILSAFE] Opschonen voor hwnd={hwnd}")
    for i in range(max_attempts):
        pyautogui.press("esc")
        # Korte pauze tussen ESC toetsen aangepast aan multiplier
        time.sleep(0.4 * config.speed_multiplier) 
        match = find_png(hwnd, "assets/bg_cancel.png", confidence=0.55, timeout=0.1)
        if match:
            click(hwnd, *CANCEL_COORD)
            time.sleep(0.5 * config.speed_multiplier)
            return True
    return False

# ==========================
# HOOFD FLOW
# ==========================

def run(hwnd):
    print(f"[AOD-STORE] Start eenmalige aankoop cyclus voor hwnd={hwnd}")

    # 1. Start altijd vanaf de kaart
    esc_failsafe(hwnd)
    time.sleep(1.0 * config.speed_multiplier)

    # 2. Voer de geregistreerde klik-reeks uit
    for i, (x, y) in enumerate(AOD_CLICKS, 1):
        print(f"[AOD-STORE] Klik {i}: ({x}, {y})")
        click(hwnd, x, y)
        
        # We geven het scherm iets meer tijd bij de eerste paar klikken 
        # omdat Arena menu's vaak zwaar zijn om te laden
        if i <= 3:
            time.sleep(2.0 * config.speed_multiplier)
        else:
            time.sleep(DEFAULT_DELAY * config.speed_multiplier)

    # 3. Eindig weer netjes op de kaart
    print("[AOD-STORE] Klikreeks voltooid. Terug naar de kaart...")
    esc_failsafe(hwnd)
    
    print(f"[AOD-STORE] Klaar voor hwnd={hwnd}")