import ctypes
from ctypes import wintypes

# ===========================
#  INSTELLINGEN (AANPASBAAR)
# ===========================

GAME_TITLE_KEYWORD = "Doomsday: Last Survivors"

# Doelpositie en -grootte (jouw standaard)
TARGET_X = 93
TARGET_Y = 100
TARGET_WIDTH = 1282
TARGET_HEIGHT = 752

# Als jij later andere maten wil (bv. 1296x759), dan pas je gewoon deze vier aan


# ===========================
#  WIN32 API DEFINITIES
# ===========================

user32 = ctypes.windll.user32

EnumWindows = user32.EnumWindows
EnumWindowsProc = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
GetWindowRect = user32.GetWindowRect
IsWindowVisible = user32.IsWindowVisible
GetWindowTextW = user32.GetWindowTextW
GetWindowTextLengthW = user32.GetWindowTextLengthW
MoveWindow = user32.MoveWindow


# ===========================
#  VENSTERS OPZOEKEN VIA TITEL
# ===========================

def get_game_windows_by_title(keyword: str = GAME_TITLE_KEYWORD) -> list:
    """
    Zoekt alle zichtbare vensters waarvan de titel 'keyword' bevat.
    Retourneert een lijst met dicts: handle, title, x, y, width, height.
    """
    windows_found = []

    def foreach_window(hwnd, lParam):
        if IsWindowVisible(hwnd):
            length = GetWindowTextLengthW(hwnd)
            if length > 0:
                buffer = ctypes.create_unicode_buffer(length + 1)
                GetWindowTextW(hwnd, buffer, length + 1)
                title = buffer.value

                if keyword.lower() in title.lower():
                    rect = wintypes.RECT()
                    GetWindowRect(hwnd, ctypes.byref(rect))
                    width = rect.right - rect.left
                    height = rect.bottom - rect.top

                    windows_found.append({
                        "handle": hwnd,
                        "title": title,
                        "x": rect.left,
                        "y": rect.top,
                        "width": width,
                        "height": height
                    })
        return True

    EnumWindows(EnumWindowsProc(foreach_window), 0)
    return windows_found


# ===========================
#  RESIZE + VERPLAATSEN
# ===========================

def resize_and_move_window(hwnd, x, y, width, height):
    """
    Verplaatst en resized één venster.
    """
    # bRepaint = True (1) zodat het venster opnieuw getekend wordt
    MoveWindow(hwnd, x, y, width, height, True)


def resize_all_game_windows(
    target_x: int = TARGET_X,
    target_y: int = TARGET_Y,
    target_width: int = TARGET_WIDTH,
    target_height: int = TARGET_HEIGHT,
    keyword: str = GAME_TITLE_KEYWORD
) -> list:
    """
    Zoek alle Doomsday-vensters en verplaats + resize ze naar de doelpositie en -grootte.
    Geeft de lijst vensters (met nieuwe pos/grootte) terug.
    """
    windows = get_game_windows_by_title(keyword)

    if not windows:
        print("[Resizer] Geen Doomsday-vensters gevonden.")
        return []

    print(f"[Resizer] Gevonden {len(windows)} Doomsday-venster(s).")
    print(f"[Resizer] Verplaats naar x={target_x}, y={target_y}, "
          f"size={target_width}x{target_height}.\n")

    for i, win in enumerate(windows, 1):
        print(f"Venster {i}: {win['title']}")
        print(f"  Oud: x={win['x']}, y={win['y']}, "
              f"width={win['width']}, height={win['height']}")
        resize_and_move_window(win["handle"], target_x, target_y, target_width, target_height)
        print(f"  Nieuw: x={target_x}, y={target_y}, width={target_width}, height={target_height}\n")

    # Na het verplaatsen: opnieuw uitlezen om de nieuwe waarden te bevestigen
    updated = get_game_windows_by_title(keyword)
    return updated


# ===========================
#  TEST-MODE
# ===========================

if __name__ == "__main__":
    print("\n======================================")
    print("      PYTHON WINDOW RESIZER TEST")
    print("======================================\n")

    print("Zorg dat al je Doomsday-vensters al draaien.")
    input("Druk op ENTER om alle vensters te resizen en verplaatsen...")

    updated_windows = resize_all_game_windows()

    if not updated_windows:
        print("\n[Resizer] ⚠ Geen vensters gevonden na resize.")
    else:
        print("\n[Resizer] ✅ Nieuwe vensterposities en -groottes:")
        for i, win in enumerate(updated_windows, 1):
            print(f"Venster {i}: {win['title']}")
            print(f"  Positie: x={win['x']}, y={win['y']}")
            print(f"  Grootte: width={win['width']}, height={win['height']}")
            print("")

    input("\nDruk op ENTER om te sluiten...")