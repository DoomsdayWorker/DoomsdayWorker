# scripts/mail.py
import time
import pyautogui
import ctypes
from ctypes import wintypes
from scripts import config  # Importeer de globale multiplier

# Win32 API setup
user32 = ctypes.windll.user32
GetWindowRect = user32.GetWindowRect

# Basis vertragingen
defaultDelay = 1.5
longDelay = 2.5
CANCEL_COORD = (501, 530)

def get_window_pos(hwnd):
    rect = wintypes.RECT()
    GetWindowRect(hwnd, ctypes.byref(rect))
    return rect.left, rect.top, rect.right, rect.bottom

def click(hwnd, x, y):
    left, top, _, _ = get_window_pos(hwnd)
    pyautogui.click(left + x, top + y)

def find_png(hwnd, image, confidence=0.70, timeout=2.0):
    left, top, right, bottom = get_window_pos(hwnd)
    width, height = right - left, bottom - top
    
    # Pas timeout aan op basis van snelheid
    actual_timeout = timeout * config.speed_multiplier
    end = time.time() + actual_timeout
    while time.time() < end:
        try:
            match = pyautogui.locateCenterOnScreen(
                image, 
                confidence=confidence, 
                region=(left, top, width, height)
            )
            if match:
                return match
        except Exception:
            pass
        time.sleep(0.1 * config.speed_multiplier)
    return None

def esc_failsafe(hwnd, max_attempts=12):
    """
    Nieuwe krachtige failsafe: blijft drukken tot de cancel-popup er is en klikt dan.
    """
    print(f"[MAIL-FAILSAFE] Opschonen voor hwnd={hwnd}")
    for i in range(max_attempts):
        pyautogui.press("esc")
        time.sleep(0.4 * config.speed_multiplier) 

        # Check of we de exit/cancel popup zien
        match = find_png(hwnd, "assets/bg_cancel.png", confidence=0.55, timeout=0.1)
        if match:
            # Klik op de vaste CANCEL_COORD
            click(hwnd, *CANCEL_COORD)
            time.sleep(0.5 * config.speed_multiplier)
            return True
            
    return False

def run(hwnd):
    print(f"[FLOW] MAIL start voor hwnd={hwnd}")

    # 1. ESC-reset aan het begin
    esc_failsafe(hwnd)
    time.sleep(1.0 * config.speed_multiplier)

    # 2. Zoek mail-icoon
    match = find_png(hwnd, "assets/mail_icon.png", confidence=0.70, timeout=3.0)
    if match is None:
        print("[MAIL] Mail-icoon niet gevonden — flow afgebroken")
        return

    # Direct klikken op de gevonden PNG locatie
    pyautogui.click(match.x, match.y)
    time.sleep(longDelay * config.speed_multiplier)

    # 3. Stappen (100% originele coördinaten)
    steps = [
        (103, 75, defaultDelay),
        (123, 704, defaultDelay),
        (278, 80, defaultDelay),
        (130, 705, defaultDelay),
        (453, 79, defaultDelay),
        (128, 708, longDelay),
        (603, 75, longDelay),
        (603, 75, longDelay),
        (134, 708, longDelay),
        (1124, 80, longDelay),
    ]

    for x, y, delay in steps:
        click(hwnd, x, y)
        time.sleep(delay * config.speed_multiplier)

    time.sleep(1.5 * config.speed_multiplier)

    # 4. Zoek sluit-icoon (als extra controle)
    close_match = find_png(hwnd, "assets/mail_close.png", confidence=0.70, timeout=2.0)
    if close_match:
        pyautogui.click(close_match.x, close_match.y)
        time.sleep(defaultDelay * config.speed_multiplier)

    # 5. ESC-failsafe aan het einde
    esc_failsafe(hwnd)

    print(f"[FLOW] MAIL voltooid voor hwnd={hwnd}")