# scripts/mail.py
import time
import pyautogui
import ctypes
from ctypes import wintypes
from scripts import config  # Importeer de globale multiplier

# Win32 API setup
user32 = ctypes.windll.user32
GetWindowRect = user32.GetWindowRect

SHORT_DELAY = 1.0
LONG_DELAY = 4.0
CANCEL_COORD = (501, 530)

# ==========================
# HELPER FUNCTIES
# ==========================

def get_window_pos(hwnd):
    rect = wintypes.RECT()
    GetWindowRect(hwnd, ctypes.byref(rect))
    return rect.left, rect.top, rect.right, rect.bottom

def click(hwnd, x, y):
    left, top, _, _ = get_window_pos(hwnd)
    pyautogui.click(left + x, top + y)

def double_click(hwnd, x, y):
    left, top, _, _ = get_window_pos(hwnd)
    pyautogui.doubleClick(left + x, top + y)

def drag(hwnd, x1, y1, x2, y2, duration=0.5):
    left, top, _, _ = get_window_pos(hwnd)
    pyautogui.moveTo(left + x1, top + y1)
    pyautogui.dragTo(left + x2, top + y2, duration=duration * config.speed_multiplier, button='left')

def find_png(hwnd, image, confidence=0.70, timeout=2.0):
    left, top, right, bottom = get_window_pos(hwnd)
    width = right - left
    height = bottom - top
    actual_timeout = timeout * config.speed_multiplier
    end = time.time() + actual_timeout
    while time.time() < end:
        try:
            match = pyautogui.locateCenterOnScreen(
                image,
                confidence=confidence,
                region=(left, top, width, height)
            )
            if match:
                return match
        except Exception:
            pass
        time.sleep(0.1 * config.speed_multiplier)
    return None

def esc_failsafe(hwnd, max_attempts=12):
    """De universele krachtige failsafe."""
    print(f"[FAILSAFE] Opschonen voor hwnd={hwnd}")
    for i in range(max_attempts):
        pyautogui.press("esc")
        time.sleep(0.4 * config.speed_multiplier)
        match = find_png(hwnd, "assets/bg_cancel.png", confidence=0.55, timeout=0.1)
        if match:
            click(hwnd, *CANCEL_COORD)
            time.sleep(0.5 * config.speed_multiplier)
            return True
    return False

# ==========================
# HOOFD FLOW
# ==========================

def run(hwnd):
    print(f"[MAIL] Start flow voor hwnd={hwnd}")

    # Start altijd vanaf een schoon scherm
    esc_failsafe(hwnd)
    time.sleep(SHORT_DELAY * config.speed_multiplier)

    # Stap 1: open mail
    match = find_png(hwnd, "assets/mail.png", confidence=0.5, timeout=2.0)
    if match:
        pyautogui.click(match.x, match.y)
    else:
        click(hwnd, 1255, 617)
    time.sleep(LONG_DELAY * config.speed_multiplier)

    # Stap 2: klik report
    click(hwnd, 106, 78)
    time.sleep(SHORT_DELAY * config.speed_multiplier)

    # Stap 3: klik read and claim
    click(hwnd, 120, 711)
    time.sleep(LONG_DELAY * config.speed_multiplier)

    # Stap 4: klik alliance
    click(hwnd, 274, 78)
    time.sleep(SHORT_DELAY * config.speed_multiplier)

    # Stap 5: klik read and claim
    click(hwnd, 144, 706)
    time.sleep(LONG_DELAY * config.speed_multiplier)

    # Stap 6: klik system
    click(hwnd, 448, 75)
    time.sleep(SHORT_DELAY * config.speed_multiplier)

    # Stap 7: klik read and claim
    click(hwnd, 138, 705)
    time.sleep(LONG_DELAY * config.speed_multiplier)

    # Stap 8: safety click
    click(hwnd, 1029, 81)
    time.sleep(SHORT_DELAY * config.speed_multiplier)

    # Stap 9: close mail
    match = find_png(hwnd, "assets/mail_close.png", confidence=0.5, timeout=2.0)
    if match:
        pyautogui.click(match.x, match.y)
    else:
        click(hwnd, 1237, 74)
    time.sleep(SHORT_DELAY * config.speed_multiplier)

    # Eindig weer netjes op de kaart
    esc_failsafe(hwnd)

    print(f"[MAIL] Klaar voor hwnd={hwnd}")