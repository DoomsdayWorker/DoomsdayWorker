# scripts/beast.py
import time
import pyautogui
import ctypes
from ctypes import wintypes
from scripts import config  # Importeer de globale multiplier

# Win32 API setup
user32 = ctypes.windll.user32
GetWindowRect = user32.GetWindowRect

DEFAULT_DELAY = 1.0
CANCEL_COORD = (501, 530)
REGIO_COORD = (81, 668)   # Beast eindigt in shelter -> terug naar regio

def get_window_pos(hwnd):
    rect = wintypes.RECT()
    GetWindowRect(hwnd, ctypes.byref(rect))
    return rect.left, rect.top, rect.right, rect.bottom

def click(hwnd, x, y):
    left, top, _, _ = get_window_pos(hwnd)
    abs_x = left + x
    abs_y = top + y
    pyautogui.click(abs_x, abs_y)

def find_png(hwnd, image, confidence=0.70, timeout=2.0):
    left, top, right, bottom = get_window_pos(hwnd)
    width = right - left
    height = bottom - top
    
    # Pas de timeout aan op basis van de snelheid
    actual_timeout = timeout * config.speed_multiplier
    end = time.time() + actual_timeout
    while time.time() < end:
        try:
            match = pyautogui.locateCenterOnScreen(
                image, 
                confidence=confidence, 
                region=(left, top, width, height)
            )
            if match:
                return match
        except Exception:
            pass
        time.sleep(0.1 * config.speed_multiplier)
    return None

def esc_failsafe(hwnd, max_attempts=12):
    """
    De nieuwe krachtige failsafe: 
    Blijft op ESC drukken tot bg_cancel.png verschijnt en klikt dan op de cancel-knop.
    """
    print(f"[FAILSAFE] Opschonen voor hwnd={hwnd}")
    for i in range(max_attempts):
        pyautogui.press("esc")
        time.sleep(0.4 * config.speed_multiplier) 

        # Check of de exit popup er is
        match = find_png(hwnd, "assets/bg_cancel.png", confidence=0.55, timeout=0.1)
        if match:
            # Gebruik de vaste coördinaat voor consistentie
            click(hwnd, *CANCEL_COORD)
            time.sleep(0.5 * config.speed_multiplier)
            return True
            
    return False

# ==========================
# HOOFD FLOW
# ==========================

def run(hwnd):
    print(f"[BEAST] Start Beast flow voor hwnd={hwnd}")

    # 1) ESC-reset aan begin
    esc_failsafe(hwnd)
    time.sleep(1.0 * config.speed_multiplier)

    # 2) Beast-icoon zoeken
    beast_match = find_png(hwnd, "assets/beast.png", confidence=0.55, timeout=3.0)

    if not beast_match:
        print("[BEAST] Beast-icoon niet gevonden -> overslaan")
        return

    # Klik op de gevonden PNG locatie
    pyautogui.click(beast_match.x, beast_match.y)
    time.sleep(DEFAULT_DELAY * config.speed_multiplier)

    # 3) Vaste coördinatenkliks
    beast_clicks = [
        (130, 69),    # Enter / Confirm
        (1113, 682),  # Start / Attack
        (932, 587),   # Claim / Result
        (1057, 150),  # Exit / Back
        (1057, 150)   # Extra Exit / Confirm
    ]

    for index, (x, y) in enumerate(beast_clicks, start=1):
        click(hwnd, x, y)
        time.sleep(DEFAULT_DELAY * config.speed_multiplier)

    # 4) ESC-reset na acties
    esc_failsafe(hwnd)
    time.sleep(0.5 * config.speed_multiplier)

    # 5) Terug naar regio (naar buiten)
    click(hwnd, *REGIO_COORD)
    # Iets langer wachten voor map-switch (4.0s standaard)
    time.sleep(4.0 * config.speed_multiplier) 

    # 6) Laatste ESC-reset om menu's die eventueel openstonden te sluiten
    esc_failsafe(hwnd)

    print(f"[BEAST] Beast flow klaar voor hwnd={hwnd}")