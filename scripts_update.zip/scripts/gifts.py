# scripts/gifts.py
import time
import pyautogui
import ctypes
from ctypes import wintypes
from scripts import config  # Importeer de globale multiplier

# Win32 API setup
user32 = ctypes.windll.user32
GetWindowRect = user32.GetWindowRect

DEFAULT_DELAY = 2.0
LONG_DELAY = 4.0

# Jouw originele coördinaten (venster-relatief)
CLICK_LIST = [
    (962, 672),     # 1
    (994, 451),     # 2
    (1120, 150),    # 3
    (46, 68),       # 4 (back arrow)
    (1186, 619),    # 5
    (1125, 209),    # 6
    (1139, 343),    # 7
    (822, 127),     # 8
    (1170, 693),    # 9 longdelay
    (404, 673),     # 10 longdelay
    (335, 346),     # 11 longdelay
    (453, 691),     # 12 longdelay
    (1104, 128),    # 13
    (1142, 216),    # 14
]

LONG_DELAY_INDEXES = {9, 10, 11, 12}
CANCEL_COORD = (501, 530)

# ==========================
# HELPER FUNCTIES
# ==========================

def get_window_pos(hwnd):
    rect = wintypes.RECT()
    GetWindowRect(hwnd, ctypes.byref(rect))
    return rect.left, rect.top, rect.right, rect.bottom

def click(hwnd, x, y):
    left, top, _, _ = get_window_pos(hwnd)
    abs_x = left + x
    abs_y = top + y
    pyautogui.click(abs_x, abs_y)

def find_png(hwnd, image, confidence=0.70, timeout=2.0):
    left, top, right, bottom = get_window_pos(hwnd)
    width = right - left
    height = bottom - top
    
    # Pas de timeout aan op basis van de snelheid
    actual_timeout = timeout * config.speed_multiplier
    end = time.time() + actual_timeout
    while time.time() < end:
        try:
            match = pyautogui.locateCenterOnScreen(
                image, 
                confidence=confidence, 
                region=(left, top, width, height)
            )
            if match:
                return match
        except Exception:
            pass
        time.sleep(0.1 * config.speed_multiplier)
    return None

def esc_failsafe(hwnd, max_attempts=12):
    """
    De universele krachtige failsafe: 
    Beukt door menu's tot bg_cancel verschijnt en klikt dan op de vaste cancel-knop.
    """
    print(f"[FAILSAFE] Opschonen voor hwnd={hwnd}")
    for i in range(max_attempts):
        pyautogui.press("esc")
        time.sleep(0.4 * config.speed_multiplier) 

        # Check voor de popup (0.55 confidence conform afspraak)
        match = find_png(hwnd, "assets/bg_cancel.png", confidence=0.55, timeout=0.1)
        if match:
            print(f"[FAILSAFE] Popup herkend. Klik op Cancel.")
            click(hwnd, *CANCEL_COORD)
            time.sleep(0.5 * config.speed_multiplier)
            return True
    return False

# ==========================
# HOOFD FLOW
# ==========================

def run(hwnd):
    print(f"[GIFTS] Start gifts flow voor hwnd={hwnd}")

    # 1) ESC-reset aan begin
    esc_failsafe(hwnd)
    time.sleep(1.0 * config.speed_multiplier)

    # 2) Gewone kliks uit de lijst
    for index, (x, y) in enumerate(CLICK_LIST, start=1):
        print(f"[GIFTS] Click {index}: ({x}, {y})")
        click(hwnd, x, y)

        # Bepaal delay en pas multiplier toe
        base_delay = LONG_DELAY if index in LONG_DELAY_INDEXES else DEFAULT_DELAY
        time.sleep(base_delay * config.speed_multiplier)

    # 3) Claim-loop (max 10)
    print("[GIFTS] Start claim-loop (PNG check)")
    max_claims = 10
    claims = 0

    while claims < max_claims:
        # Hier houden we de claim-specifieke confidence op 0.65 zoals in jouw origineel
        match = find_png(hwnd, "assets/claim.png", confidence=0.65, timeout=1.5)
        
        if not match:
            print("[GIFTS] Geen claim.png meer gevonden.")
            break

        claims += 1
        print(f"[GIFTS] Claim {claims} uitvoeren")
        pyautogui.click(match.x, match.y)
        # Vertraging tussen claims ook afhankelijk van multiplier
        time.sleep(2.0 * config.speed_multiplier)

    print(f"[GIFTS] Claim-loop klaar ({claims} claims uitgevoerd)")

    # 4) ESC-resets aan het einde om alliance menu volledig te verlaten
    esc_failsafe(hwnd)

    print(f"[GIFTS] Klaar voor hwnd={hwnd}")