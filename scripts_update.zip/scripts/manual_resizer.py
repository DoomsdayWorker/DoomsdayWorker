import ctypes
from ctypes import wintypes

# ===========================
#  WIN32 API DEFINITIES
# ===========================
user32 = ctypes.windll.user32
EnumWindows = user32.EnumWindows
EnumWindowsProc = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
GetWindowRect = user32.GetWindowRect
IsWindowVisible = user32.IsWindowVisible
GetWindowTextW = user32.GetWindowTextW
GetWindowTextLengthW = user32.GetWindowTextLengthW
MoveWindow = user32.MoveWindow
AdjustWindowRect = user32.AdjustWindowRect

GAME_TITLE_KEYWORD = "Doomsday: Last Survivors"

# Window Styles voor de berekening (Standaard venster met titelbalk en randen)
WS_OVERLAPPEDWINDOW = 0x00CF0000

def get_game_windows_by_title(keyword: str = GAME_TITLE_KEYWORD) -> list:
    """Zoekt alle zichtbare game vensters."""
    windows_found = []

    def foreach_window(hwnd, lParam):
        if IsWindowVisible(hwnd):
            length = GetWindowTextLengthW(hwnd)
            if length > 0:
                buffer = ctypes.create_unicode_buffer(length + 1)
                GetWindowTextW(hwnd, buffer, length + 1)
                title = buffer.value

                if keyword.lower() in title.lower():
                    rect = wintypes.RECT()
                    GetWindowRect(hwnd, ctypes.byref(rect))
                    windows_found.append({
                        "handle": hwnd,
                        "title": title,
                        "x": rect.left,
                        "y": rect.top,
                        "width": rect.right - rect.left,
                        "height": rect.bottom - rect.top
                    })
        return True

    EnumWindows(EnumWindowsProc(foreach_window), 0)
    return windows_found

def run_manual_resize(target_width, target_height, target_x=93, target_y=100):
    """
    De hoofdfunctie die wordt aangeroepen vanuit de GUI.
    Zet alle vensters op de opgegeven resolutie op positie (93, 100).
    Inclusief correctie voor vensterranden zodat de content (het spel) de juiste maat behoudt.
    """
    windows = get_game_windows_by_title()

    if not windows:
        print("[Manual Resizer] Geen spelvensters gevonden.")
        return False

    # --- BEREKENING VAN DE VENSTERRANDEN ---
    # We maken een RECT die de gewenste 'binnenmaat' (client area) voorstelt
    rect = wintypes.RECT()
    rect.left = 0
    rect.top = 0
    rect.right = target_width
    rect.bottom = target_height

    # AdjustWindowRect rekent uit hoe groot het venster inclusief randen moet zijn
    AdjustWindowRect(ctypes.byref(rect), WS_OVERLAPPEDWINDOW, False)
    
    # De nieuwe breedte en hoogte inclusief de Windows-omlijsting
    final_width = rect.right - rect.left
    final_height = rect.bottom - rect.top

    print(f"[Manual Resizer] {len(windows)} vensters worden aangepast.")
    print(f"[Manual Resizer] Doel speelveld: {target_width}x{target_height}")
    print(f"[Manual Resizer] Werkelijke venstermaat: {final_width}x{final_height}")

    for win in windows:
        # MoveWindow met de gecorrigeerde maten
        MoveWindow(win["handle"], target_x, target_y, final_width, final_height, True)
    
    return True