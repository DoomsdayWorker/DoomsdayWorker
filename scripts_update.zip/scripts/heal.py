# scripts/heal.py
import time
import pyautogui
import ctypes
from ctypes import wintypes
from scripts import config

user32 = ctypes.windll.user32
GetWindowRect = user32.GetWindowRect

HEAL_TAB_COORD = (1192, 492)

session_hospital_map = {}

def get_window_pos(hwnd):
    rect = wintypes.RECT()
    GetWindowRect(hwnd, ctypes.byref(rect))
    return rect.left, rect.top, rect.right, rect.bottom

def click(hwnd, x, y):
    left, top, _, _ = get_window_pos(hwnd)
    pyautogui.click(left + x, top + y)

def find_png(hwnd, image, confidence=0.60, timeout=1.0):
    left, top, right, bottom = get_window_pos(hwnd)
    width, height = right - left, bottom - top
    # Kortere timeouts voor maximale snelheid
    actual_timeout = timeout * config.speed_multiplier
    end = time.time() + actual_timeout
    while time.time() < end:
        try:
            match = pyautogui.locateCenterOnScreen(f"assets/{image}", confidence=confidence, region=(left, top, width, height))
            if match:
                return match
        except:
            pass
        time.sleep(0.05) # Snellere scan-interval
    return None

def run(hwnd, heal_amount):
    print(f"[HEAL] High-Speed Mode gestart voor hwnd={hwnd}")
    multiplier = config.speed_multiplier

    while True:
        # STAP 1: ZOEK HOSPITAL PNG + LOCATIE OPSLAAN
        h_pos = find_png(hwnd, "hospital.png", confidence=0.60, timeout=2.0)
        
        if not h_pos:
            print(f"[HEAL] Geen hospital.png meer. Klaar.")
            break
            
        session_hospital_map[hwnd] = h_pos

        # STAP 2: OPEN MENU
        pyautogui.click(h_pos.x, h_pos.y)
        time.sleep(1.2 * multiplier) # Snelle menu-wachttijd

        # STAP 3: START HEALING (Menu sluit vanzelf)
        click(hwnd, *HEAL_TAB_COORD)
        time.sleep(0.4 * multiplier) # Razendsnelle tab-wissel

        troop_match = find_png(hwnd, "troop_count.png", confidence=0.60, timeout=1.5)
        if troop_match:
            pyautogui.click(troop_match.x, troop_match.y)
            # Snelle input zonder pauzes tussen toetsen
            pyautogui.hotkey('ctrl', 'a')
            pyautogui.press('backspace')
            pyautogui.write(str(heal_amount))
            
            start_pos = find_png(hwnd, "start_heal.png", confidence=0.60, timeout=1.0)
            if start_pos:
                pyautogui.click(start_pos.x, start_pos.y)
                # Korte pauze tot menu weg is en groen verschijnt
                time.sleep(1.0 * multiplier) 
            else:
                break
        else:
            break

        # STAP 4: WACHTEN TOT GROEN WEG IS
        # Hier mag hij snel scannen zonder veel rust
        while True:
            if not find_png(hwnd, "healing_progress.png", confidence=0.60, timeout=0.3):
                break
            time.sleep(0.3) # Korte pauze tussen scans

        # STAP 5: COLLECT OP OPGESLAGEN LOCATIE
        h_mem = session_hospital_map[hwnd]
        pyautogui.click(h_mem.x, h_mem.y)
        
        # Minimale pauze voor de collect-animatie voordat we weer bij Stap 1 scannen
        time.sleep(0.8 * multiplier)

    return "next"