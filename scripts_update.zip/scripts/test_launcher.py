# scripts/test_launcher.py
import subprocess
import time
import os

def launch_sandbox(sandbox_exe, box_name, game_exe):
    """
    Start een specifieke sandbox met het spel.
    """
    if not os.path.exists(sandbox_exe):
        print(f"[ERROR] Sandboxie EXE niet gevonden: {sandbox_exe}")
        return False
        
    if not os.path.exists(game_exe):
        print(f"[ERROR] Game EXE niet gevonden: {game_exe}")
        return False

    try:
        # Het commando: "C:\Pad\SandMan.exe" /box:Naam "C:\Pad\Game.exe"
        command = [sandbox_exe, f"/box:{box_name}", game_exe]
        
        # We gebruiken Popen zodat de GUI niet vastloopt terwijl het spel laadt
        subprocess.Popen(command)
        print(f"[SUCCESS] Start-commando verzonden naar box: {box_name}")
        return True
    except Exception as e:
        print(f"[ERROR] Fout tijdens het starten van {box_name}: {e}")
        return False

if __name__ == "__main__":
    # Dit gedeelte is alleen voor handmatig testen buiten de GUI om
    # Vul hier je eigen paden in als je dit script los wilt draaien
    S_EXE = r"C:\Program Files\Sandboxie-Plus\SandMan.exe"
    G_EXE = r"C:\Program Files (x86)\Doomsday\DoomsdayLastSurvivors.exe"
    launch_sandbox(S_EXE, "DefaultBox", G_EXE)