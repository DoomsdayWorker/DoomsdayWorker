import time

# De GUI past deze waarde aan (0.5 tot 2.0)
speed_multiplier = 1.0

def short_sleep():
    """Vervangt jouw 2 sec pauzes. Beïnvloed door GUI."""
    time.sleep(2.0 * speed_multiplier)

def long_sleep():
    """Vervangt jouw 4 sec pauzes. Beïnvloed door GUI."""
    time.sleep(4.0 * speed_multiplier)