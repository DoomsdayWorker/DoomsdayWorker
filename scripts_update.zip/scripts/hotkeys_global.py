import threading
import keyboard  # pip install keyboard

class GlobalHotkeys:
    def __init__(self, on_pause, on_stop):
        self.on_pause = on_pause
        self.on_stop = on_stop
        self.thread = threading.Thread(target=self._run, daemon=True)

    def start(self):
        self.thread.start()

    def _run(self):
        keyboard.add_hotkey('F7', self.on_pause)
        keyboard.add_hotkey('F8', self.on_stop)
        keyboard.wait()  # blokkeert deze thread, niet de GUI